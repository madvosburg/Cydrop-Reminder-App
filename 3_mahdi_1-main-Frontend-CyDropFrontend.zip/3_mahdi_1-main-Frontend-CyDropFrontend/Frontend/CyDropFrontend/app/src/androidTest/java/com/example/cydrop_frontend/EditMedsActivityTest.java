package com.example.cydrop_frontend;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;

import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class EditMedsActivityTest {

    /**
     * This method runs before each test case to set up the scenario.
     */
    @Before
    public void setUp() {
        // Launch the EditMedsActivity
        ActivityScenario.launch(EditMedsActivity.class);
    }

    /**
     * Test to check if the activity launches and UI elements are displayed.
     */
    @Test
    public void testActivityLaunch() {
        // Check if the EditText for medication ID is visible
        onView(withId(R.id.et_medication_name_prev)).check(matches(isDisplayed()));

        // Check if the EditText for new medication name is visible
        onView(withId(R.id.et_medication_name_new)).check(matches(isDisplayed()));

        // Check if the EditText for medication stock is visible
        onView(withId(R.id.et_medication_stock)).check(matches(isDisplayed()));

        // Check if the Edit button is visible
        onView(withId(R.id.btn_edit)).check(matches(isDisplayed()));

        // Check if the Add button is visible
        onView(withId(R.id.btn_add)).check(matches(isDisplayed()));

        // Check if the Delete button is visible
        onView(withId(R.id.btn_delete)).check(matches(isDisplayed()));

        // Check if the Return button is visible
        onView(withId(R.id.btn_return)).check(matches(isDisplayed()));
    }

    /**
     * Test to check if input fields are functioning properly.
     */
    @Test
    public void testInputFields() {
        // Type the old medication name (ID)
        onView(withId(R.id.et_medication_name_prev)).perform(typeText("20"));

        // Type the new medication name
        onView(withId(R.id.et_medication_name_new)).perform(typeText("NewTestMed"));

        // Type the stock quantity
        onView(withId(R.id.et_medication_stock)).perform(typeText("50"));
    }

    /**
     * Test to check if clicking the Edit button triggers a PUT request.
     */
//    @Test
//    public void testEditButtonClick() {
//        // Type the old medication name (ID)
//        onView(withId(R.id.et_medication_name_prev)).perform(typeText("40"));
//
//        // Type the new medication name
//        onView(withId(R.id.et_medication_name_new)).perform(typeText("NewTestMed"));
//
//        // Type the stock quantity
//        onView(withId(R.id.et_medication_stock)).perform(typeText("50"));
//
//        // Click the Edit button
//        onView(withId(R.id.btn_edit)).perform(click());
//
//        // Verify that a success Toast message is displayed
//      //  onView(withText("Medication Updated")).check(matches(isDisplayed()));
//    }

    /**
     * Test to check if clicking the Add button triggers a POST request.
     */
    @Test
    public void testAddButtonClick() {
        // Type the new medication name
        onView(withId(R.id.et_medication_name_new)).perform(typeText("NewTestMed"));

        // Type the stock quantity
        onView(withId(R.id.et_medication_stock)).perform(typeText("50"));

        // Click the Add button
        onView(withId(R.id.btn_add)).perform(click());

        // Verify that a success Toast message is displayed
       // onView(withText("Medication Added")).check(matches(isDisplayed()));
    }

    /**
     * Test to check if clicking the Delete button triggers a DELETE request.
     */
    @Test
    public void testDeleteButtonClick() {
        // Type the medication ID to delete
        onView(withId(R.id.et_medication_name_prev)).perform(typeText("40"));

        // Click the Delete button
        onView(withId(R.id.btn_delete)).perform(click());

        // Verify that a success Toast message is displayed
      //  onView(withText("Medication Deleted")).check(matches(isDisplayed()));
    }

    /**
     * Test to check if clicking the Return button navigates back to the AdminNavbarMainActivity.
     */
    @Test
    public void testReturnButtonClick() {
        // Click on the return button
        onView(withId(R.id.btn_return)).perform(click());

        // Check if the AdminNavbarMainActivity is displayed
        onView(withId(R.id.frame_layout)).check(matches(isDisplayed())); // Replace with an ID from AdminNavbarMainActivity
    }
}