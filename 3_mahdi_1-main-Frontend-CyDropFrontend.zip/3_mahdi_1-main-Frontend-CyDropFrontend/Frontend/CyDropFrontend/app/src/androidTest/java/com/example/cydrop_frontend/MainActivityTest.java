package com.example.cydrop_frontend;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;

import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class MainActivityTest {

    /**
     * This method runs before each test case to set up the scenario.
     */
    @Before
    public void setUp() {
        // Launch the MainActivity
        ActivityScenario.launch(MainActivity.class);
    }

    /**
     * Test to check if the activity launches and the UI elements are displayed.
     */
    @Test
    public void testActivityLaunch() {
        // Check if the login button is visible
        onView(withId(R.id.main_login_button)).check(matches(isDisplayed()));

        // Check if the signup button is visible
        onView(withId(R.id.main_signup_btn)).check(matches(isDisplayed()));
    }

    /**
     * Test to check if the Login button navigates to the LoginActivity.
     */
    @Test
    public void testLoginButtonClick() {
        // Click on the login button
        onView(withId(R.id.main_login_button)).perform(click());

        // Check if the LoginActivity is launched (assuming LoginActivity has a unique ID)
        onView(withId(R.id.login_display_text)).check(matches(isDisplayed()));
    }

    /**
     * Test to check if the Signup button navigates to the SignupActivity.
     */
    @Test
    public void testSignupButtonClick() {
        // Click on the signup button
        onView(withId(R.id.main_signup_btn)).perform(click());

        // Check if the SignupActivity is launched (assuming SignupActivity has a unique ID)
        onView(withId(R.id.signup_username_edt)).check(matches(isDisplayed()));
    }

}