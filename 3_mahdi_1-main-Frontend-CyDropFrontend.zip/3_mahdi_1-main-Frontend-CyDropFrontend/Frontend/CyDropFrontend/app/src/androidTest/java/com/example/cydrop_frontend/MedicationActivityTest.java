package com.example.cydrop_frontend;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.withSpinnerText;

import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class MedicationActivityTest {

    /**
     * This method runs before each test case to set up the scenario.
     */
    @Before
    public void setUp() {
        // Launch the MedicationActivity
        ActivityScenario.launch(MedicationActivity.class);
    }

    /**
     * Test to check if the activity launches and UI elements are displayed.
     */
    @Test
    public void testActivityLaunch() {
        // Check if the pet spinner is visible
        onView(withId(R.id.spinner_pets)).check(matches(isDisplayed()));

        // Check if the medication type spinner is visible
        onView(withId(R.id.spinner_medication_type)).check(matches(isDisplayed()));

        // Check if the return button is visible
        onView(withId(R.id.btn_return)).check(matches(isDisplayed()));

        // Check if the assign medication button is visible
        onView(withId(R.id.btn_assign_medication)).check(matches(isDisplayed()));
    }

    /**
     * Test to check if the pet and medication type spinners have data.
     */
    @Test
    public void testSpinnersData() {
        // Check if the pet spinner has at least one item (simulating loading data)
        onView(withId(R.id.spinner_pets)).check(matches(withSpinnerText("1")));

        // Check if the medication type spinner has at least one item (simulating loading data)
        onView(withId(R.id.spinner_medication_type)).check(matches(withSpinnerText("1")));
    }

    /**
     * Test to check if clicking the Return button navigates back to the VetNavbarMainActivity.
     */
    @Test
    public void testReturnButtonClick() {
        // Click on the return button
        onView(withId(R.id.btn_return)).perform(click());

        // Check if the VetNavbarMainActivity is displayed (assuming a unique ID exists in the next activity)
        onView(withId(R.id.frame_layout)).check(matches(isDisplayed()));
    }

    /**
     * Test to check if the Assign Medication button triggers the correct action.
     */
//    @Test
//    public void testAssignMedicationButtonClick() {
//        // Select a pet from the pet spinner (replace with a valid pet ID or name)
//        onView(withId(R.id.spinner_pets)).perform(click());
//        // Select a medication type from the medication type spinner (replace with a valid med type ID)
//        onView(withId(R.id.spinner_medication_type)).perform(click());
//
//        // Click the Assign Medication button
//      //  onView(withId(R.id.btn_assign_medication)).perform(click());
//
//        // Verify that a success Toast message is displayed
//      //  onView(withText("Medication Assigned")).check(matches(isDisplayed()));
//
//    }
}
