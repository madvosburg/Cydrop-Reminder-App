package com.example.cydrop_frontend;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MedicationActivity extends AppCompatActivity {

    private TextView msgResponse;
    private Spinner petSpinner, medicationTypeSpinner;
    private String vetId; // Variable to store the retrieved vet_id

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meds);

        // Initialize views
        petSpinner = findViewById(R.id.spinner_pets);
        medicationTypeSpinner = findViewById(R.id.spinner_medication_type);
       // msgResponse = findViewById(R.id.msgResponse);

        // Load pets and medication types
        loadPets();
        loadMedicationTypes();
        getVetId();

        findViewById(R.id.btn_return).setOnClickListener(view -> {
            Intent intent = new Intent(MedicationActivity.this, VetNavbarMainActivity.class);
            startActivity(intent);
        });

        // Button to assign medication
        findViewById(R.id.btn_assign_medication).setOnClickListener(view -> {
            String selectedPet = petSpinner.getSelectedItem().toString();
            String selectedMedicationType = medicationTypeSpinner.getSelectedItem().toString();
            updatePetMedication(selectedPet, selectedMedicationType);
        });
    }

    private void getVetId() {
        String url = "http://coms-3090-038.class.las.iastate.edu:8080/vet-id/" + VolleySingleton.email;

        // Send GET request to retrieve the vet ID
        StringRequest request = new StringRequest(
                Request.Method.GET,
                url,
                response -> {
                        Log.d("Vet ID Response", "Response: " + response);
                        vetId = response.trim();
                },
                error -> {
                    Log.e("Volley Error", error.toString());
                    Toast.makeText(getApplicationContext(), "Failed to retrieve Vet ID", Toast.LENGTH_LONG).show();
                    // random comment
                }
        );

        VolleySingleton.getInstance(getApplicationContext()).addToRequestQueue(request);
    }

    private void updatePetMedication(String petId, String medId) {
        // URL to update a specific pet's medication
        String url = "http://coms-3090-038.class.las.iastate.edu:8080/vet-assign/" + vetId + "/" + petId + "/" + medId;

        // Create an empty JSON object as the request body (if required by the API)
        JSONObject requestData = new JSONObject();

        // Send PUT request to update the pet's medication
        StringRequest updateRequest = new StringRequest(
                Request.Method.POST,
                url,
                response -> {
                    Toast.makeText(getApplicationContext(), "Medication Assigned", Toast.LENGTH_LONG).show();
                },
                error -> {
                    Log.e("Volley Error", error.toString());
                    Toast.makeText(getApplicationContext(), "Failed to assign medication", Toast.LENGTH_SHORT).show();
                }
        );

        VolleySingleton.getInstance(getApplicationContext()).addToRequestQueue(updateRequest);
    }

    private void loadPets() {
        JsonArrayRequest request = new JsonArrayRequest(
                Request.Method.GET,
                "http://coms-3090-038.class.las.iastate.edu:8080/pets",
                null,
                response -> {
                    try {
                        JSONArray pets = response;
                        // Populate the spinner with pet IDs instead of pet names
                        String[] petIds = new String[pets.length()];
                        for (int i = 0; i < pets.length(); i++) {
                            JSONObject pet = pets.getJSONObject(i);
                            petIds[i] = pet.getString("pet_id");
                        }

                        // Populate the Spinner for pet IDs
                        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, petIds);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        petSpinner.setAdapter(adapter);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> Log.e("Volley Error", error.toString())
        );

        VolleySingleton.getInstance(getApplicationContext()).addToRequestQueue(request);
    }

    private void loadMedicationTypes() {
        JsonArrayRequest request = new JsonArrayRequest(
                Request.Method.GET,
                "http://coms-3090-038.class.las.iastate.edu:8080/inventory",
                null,
                response -> {
                    try {
                        JSONArray types = response;
                        // Populate the spinner with medication types
                        String[] medicationTypes = new String[types.length()];
                        for (int i = 0; i < types.length(); i++) {
                            JSONObject type = types.getJSONObject(i);
                            medicationTypes[i] = type.getString("id");
                        }

                        // Populate the Spinner for medication types
                        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, medicationTypes);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        medicationTypeSpinner.setAdapter(adapter);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> Log.e("Volley Error", error.toString())
        );

        VolleySingleton.getInstance(getApplicationContext()).addToRequestQueue(request);
    }
}